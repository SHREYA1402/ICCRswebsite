import React from 'react'

export const Feature = () => {
  return (
    <div>Features of products</div>
  )
}
