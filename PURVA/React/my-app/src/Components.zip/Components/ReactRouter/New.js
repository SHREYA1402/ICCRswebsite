import React from 'react'

export const New = () => {
  return (
    <div>New products added</div>
  )
}
